INSERT INTO "Companies" (company_name, ceo_id, EMPLOYEE_COUNT) VALUES ('DanubeShipping OOD', 101, 4);
INSERT INTO "Companies" (company_name, ceo_id, EMPLOYEE_COUNT) VALUES ('WorldSights LTD', 201, 5);


INSERT INTO Employees (emp_id, name, position, salary, company_name, status) VALUES (101, 'Драган Василев', 'CEO', 90000, 'DanubeShipping OOD', 'Свободен');
INSERT INTO Employees (emp_id, name, position, salary, company_name, status) VALUES (102, 'Петър Димитров', 'Captain', 7000, 'DanubeShipping OOD', 'Свободен');
INSERT INTO Employees (emp_id, name, position, salary, company_name, status) VALUES (103, 'Иван Иванов', 'Mechanic', 6500, 'DanubeShipping OOD', 'Свободен');
INSERT INTO Employees (emp_id, name, position, salary, company_name, status) VALUES (104, 'Георги Владимиров', 'Sailor', 3000, 'DanubeShipping OOD', 'Свободен');

INSERT INTO Employees (emp_id, name, position, salary, company_name, status) VALUES (201, 'Ангел Йорданов', 'CEO', 85000, 'WorldSights LTD', 'Свободен');
INSERT INTO Employees (emp_id, name, position, salary, company_name, status) VALUES (202, 'Стоян Янев', 'Captain', 7100, 'WorldSights LTD', 'Свободен');
INSERT INTO Employees (emp_id, name, position, salary, company_name, status) VALUES (203, 'Теодор Колев', 'Mechanic', 6600, 'WorldSights LTD', 'Свободен');
INSERT INTO Employees (emp_id, name, position, salary, company_name, status) VALUES (204, 'Христо Христов', 'Sailor', 3000, 'WorldSights LTD', 'Свободен');
INSERT INTO Employees (emp_id, name, position, salary, company_name, status) VALUES (205, 'Николай Маринов', 'Sailor', 3100, 'WorldSights LTD', 'Свободен');


INSERT INTO Ships (name, type, max_load, company_name, status) VALUES ('Никола Вапцаров', 'Тласкач', 10000, 'DanubeShipping OOD', 'Свободен');
INSERT INTO Ships (name, type, max_load, company_name, status) VALUES ('Петър Берон', 'Влекач', 7000, 'DanubeShipping OOD', 'Свободен');


INSERT INTO Ships (name, type, max_load, company_name, status) VALUES ('Sea breeze Dreamer', 'Пасажерски', 500, 'WorldSights LTD', 'Свободен');
INSERT INTO Ships (name, type, max_load, company_name, status) VALUES ('Starlight Voyager', 'Пасажерски', 700, 'WorldSights LTD', 'На ремонт');



INSERT INTO Courses (course_id, ship_name, cargo_type, cargo_weight, cargo_value, departure_location, destination, departure_date, arrival_date) 
             VALUES (1, 'Никола Вапцаров', 'Чакъл', 8000, 52000, 'Ruse', 'Constanța', '2024-03-01', '2024-03-6');

INSERT INTO Courses (course_id, ship_name, cargo_type, cargo_weight, cargo_value, departure_location, destination, departure_date, arrival_date) 
             VALUES (2, 'Starlight Voyager', 'ХОРА', 650, 65000, 'Budapest', 'Varna', '2024-02-02', '2024-04-15');


INSERT INTO CrewAssignments (course_id, emp_id, role) VALUES (1, 102, 'Captain');
INSERT INTO CrewAssignments (course_id, emp_id, role) VALUES (1, 103, 'Senior Mechanic');
INSERT INTO CrewAssignments (course_id, emp_id, role) VALUES (2, 204, 'Sailor');

INSERT INTO CrewAssignments (course_id, emp_id, role) VALUES (2, 202, 'Captain');
INSERT INTO CrewAssignments (course_id, emp_id, role) VALUES (2, 203, 'Senior Mechanic');
INSERT INTO CrewAssignments (course_id, emp_id, role) VALUES (2, 204, 'Sailor');
INSERT INTO CrewAssignments (course_id, emp_id, role) VALUES (2, 205, 'Sailor');
