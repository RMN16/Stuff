CREATE or replace VIEW EmployeeCompanyView AS
SELECT e.emp_id, e.name, e.position, e.salary, c.company_name, c.ceo_id
FROM FN24_2MI0400008.EMPLOYEES e
JOIN FN24_2MI0400008."Companies" c ON e.company_name = c.company_name;

SELECT * FROM EmployeeCompanyView;


CREATE or replace VIEW CourseShipView AS
SELECT c.course_id, c.SHIP_NAME, s.type, s.max_load, c.cargo_type, c.cargo_weight, c.cargo_value, c.departure_location, c.destination, c.departure_date, c.arrival_date
FROM FN24_2MI0400008.COURSES c
JOIN FN24_2MI0400008.SHIPS s ON c.SHIP_NAME = s.name;

SELECT * FROM CourseShipView;
