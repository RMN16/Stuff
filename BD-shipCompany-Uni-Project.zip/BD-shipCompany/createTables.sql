CREATE TABLE Companies (
    company_name VARCHAR(100) not null PRIMARY KEY,
    ceo_id INT,
    employee_count INT
);

CREATE TABLE Ships (
    name VARCHAR(100) not null PRIMARY KEY,
    type VARCHAR(50),
    max_load DECIMAL,
    company_name VARCHAR(100),
    status VARCHAR(50),
    FOREIGN KEY (company_name) REFERENCES "Companies"(company_name)
);

CREATE TABLE Employees (
    emp_id INT not null PRIMARY KEY,
    name VARCHAR(100),
    position VARCHAR(50),
    salary DECIMAL,
     company_name VARCHAR(100),
    status VARCHAR(50),
    FOREIGN KEY (company_name) REFERENCES "Companies"(company_name)
);

CREATE TABLE Courses (
    course_id INT not null PRIMARY KEY,
    ship_name VARCHAR(100),
    cargo_type VARCHAR(50),
    cargo_weight DECIMAL,
    cargo_value DECIMAL,
    departure_location VARCHAR(100),
    destination VARCHAR(100),
    departure_date DATE,
    arrival_date DATE,
    FOREIGN KEY (ship_name) REFERENCES Ships(name)
);

CREATE TABLE CrewAssignments (
    course_id INT,
    emp_id INT,
    role VARCHAR(50),
    FOREIGN KEY (course_id) REFERENCES Courses(course_id),
    FOREIGN KEY (emp_id) REFERENCES Employees(emp_id)
);
