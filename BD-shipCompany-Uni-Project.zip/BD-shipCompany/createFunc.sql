CREATE OR REPLACE FUNCTION TotalSalaryByCompany(companyName VARCHAR(100)) RETURNS VARCHAR(255)
BEGIN
  DECLARE total DECIMAL(30,5);

    SELECT sum(EMPLOYEES.salary) into total FROM FN24_2MI0400008.EMPLOYEES WHERE companyName = EMPLOYEES.COMPANY_NAME;
    RETURN CAST(total AS VARCHAR(255)); -- Convert to string for return value because it's too big
END;

SELECT distinct FN24_2MI0400008.TotalSalaryByCompany('DanubeShipping OOD') from FN24_2MI0400008.EMPLOYEES;




CREATE OR REPLACE FUNCTION IsShipFree(shipName VARCHAR(100)) RETURNS INT
BEGIN
    DECLARE status VARCHAR(50);
    SELECT s1.status INTO status FROM Ships s1 WHERE s1.name = shipName;
    IF status = 'Свободен' THEN
        RETURN 1; -- Return 1 for "Free" status
    ELSE
        RETURN 0; -- Return 0 for any other status
    END IF;
END;
SELECT distinct FN24_2MI0400008.IsShipFree('Starlight Voyager') from FN24_2MI0400008.SHIPS;
SELECT distinct FN24_2MI0400008.IsShipFree('Никола Вапцаров') from FN24_2MI0400008.SHIPS;

