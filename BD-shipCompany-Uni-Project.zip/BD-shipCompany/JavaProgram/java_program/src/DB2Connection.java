import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DB2Connection {

    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;


    public void openConnection() {

        // Step 1: Load IBM DB2 JDBC driver
        try {

            DriverManager.registerDriver(new com.ibm.db2.jcc.DB2Driver());
        }
        catch (Exception cnfex) {
            System.out.println("Problem in loading or registering IBM DB2 JDBC driver");
            cnfex.printStackTrace();
        }

// Step 2: Opening database connection
        try {
            connection = DriverManager.getConnection("jdbc:db2://62.44.108.24:50000/SAMPLE", "db2admin", "db2admin"); //what ip do i need????
            statement = connection.createStatement();
        } catch (SQLException s) {
            s.printStackTrace();
        }
    }

    public void closeConnection() {
        try {
            if(null != connection) {

                // cleanup resources, once after processing
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();

                connection.close();
            }
        } catch (SQLException s) {
            s.printStackTrace();
        }
    }

    //SELECT
    public void select(String stmnt, int column) {
        try {
            resultSet = statement.executeQuery(stmnt);
            String result = "";

            while (resultSet.next()) {
                for (int i = 1; i <= column; i++) {
                    result += resultSet.getString(i);
                    if (i == column) result += " \n";
                    else result += ", ";
                }
            }

            System.out.println("Executing query: " + stmnt + "\n");
            System.out.println("Result output \n");
            System.out.println("---------------------------------- \n");
            System.out.println(result);

        } catch (SQLException s) {
            s.printStackTrace();
        }
    }

    // INSERT
    public void insert(String stmnt) {
        try {
            statement.executeUpdate(stmnt);
            System.out.println("Successfully inserted!");
        } catch (SQLException s) {
            System.out.println("NOT inserted!");
            s.printStackTrace();
        }
    }

    // DELETE
    public void delete(String stmnt) {
        try {
            statement.executeUpdate(stmnt);
            System.out.println("Successfully deleted!");
        } catch (SQLException s) {
            s.printStackTrace();
        }
    }

    // MAIN
    public static void main(String[] args) {
        DB2Connection db2Obj = new DB2Connection();
        String stmnt = "";

        db2Obj.openConnection();

        //SELECT example
        stmnt = "SELECT name, position FROM FN24_2MI0400008.Employees WHERE status = 'Свободен'";
        db2Obj.select(stmnt, 2);

        //INSERT example
        stmnt = "INSERT INTO FN24_2MI0400008.Employees (emp_id, name, position, salary, company_name, status) VALUES (107, 'Димитър Илиев', 'Sailor', 2700, 'DanubeShipping OOD', 'Свободен')";
        db2Obj.insert(stmnt);

        //SELECT example
        stmnt = "SELECT name, position FROM FN24_2MI0400008.Employees WHERE status = 'Свободен'";
        db2Obj.select(stmnt, 2);

        //DELETE example
        stmnt = "DELETE FROM FN24_2MI0400008.Employees WHERE emp_id = 107";
        db2Obj.delete(stmnt);

        db2Obj.closeConnection();
    }
}