CREATE OR REPLACE TRIGGER UpdateEmployeeCountAfterInsertDelete
AFTER INSERT OR DELETE ON FN24_2MI0400008.EMPLOYEES
REFERENCING NEW AS NEW_ROW OLD AS OLD_ROW
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        UPDATE FN24_2MI0400008."Companies" C
        SET C.employee_count = C.employee_count + 1
        WHERE C.company_name = NEW_ROW.COMPANY_NAME;
    END IF;

    IF DELETING THEN
        UPDATE FN24_2MI0400008."Companies" C
        SET C.employee_count = C.employee_count - 1
        WHERE C.company_name = OLD_ROW.COMPANY_NAME;
    END IF;
END;

SELECT * FROM FN24_2MI0400008."Companies";
INSERT INTO FN24_2MI0400008.EMPLOYEES (emp_id, name, position, salary, company_name, status) VALUES (105, 'Мариан Николов', 'Mechanic', 5000, 'DanubeShipping OOD', 'Свободен');
SELECT * FROM FN24_2MI0400008."Companies";
delete from FN24_2MI0400008.EMPLOYEES where EMP_ID = 105;


CREATE OR REPLACE TRIGGER UpdateShipStatusAfterInsertCourse
AFTER INSERT ON Courses
REFERENCING NEW AS NEW_ROW
FOR EACH ROW
BEGIN
    UPDATE Ships SET status = 'Отплавал' WHERE NAME = NEW_ROW.SHIP_NAME;
END;

SELECT * FROM Ships;
INSERT INTO Courses (course_id, ship_name, cargo_type, cargo_weight, cargo_value, departure_location, destination, departure_date, arrival_date) 
             VALUES (3, 'Петър Берон', 'Скрап', 5000, 10000, 'Vidin', 'Budapest', '2024-06-01', '2024-06-12');
SELECT * FROM Ships;


