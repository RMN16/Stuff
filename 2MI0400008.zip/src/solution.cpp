#include "solution.h"

#include <cassert>
#include <cmath>
#include <stdexcept>
#include <stack>

#include <iostream>

/// Performs an operation on two arguments
///
/// @param operation
///    The code of the operation as a character. Can be +, -, *, / or ^
///
/// @param left
///    First argument of the operation 
///
/// @param right
///    Second argument of the operation
///
/// @exception std::invalid_argument
///    If an invalid operation is passed to the function or
///    if the operation is division (/) and the right argument is 0.
///
double perform(char operation, double left, double right)
{
	switch(operation) {
		case '+': return left + right;
		case '-': return left - right;
		case '*': return left * right;
		case '^': return std::pow(left, right);
		case '/':
			if(right == 0)
				throw std::invalid_argument("Division by zero");
			return left / right;
		
		default:
			throw std::invalid_argument("Invalid operation symbol passed to perform()");
	}
}

double evaluateRpn(const char* rpn)
{
	if (rpn == nullptr)
	{ 
		throw std::invalid_argument("The RPN that you've chosen is invalid (aka nullptr)");
	}

	std::stack<double> dStack;
	double answer = 0;

	int slen = strlen(rpn);

	for (size_t i = 0; i < slen; i++)
	{
		char parser = *rpn + i;

		if (isDigit(parser))
			{
				dStack.push(toDouble(parser));
			}
		else if (isOperation(parser))
		{
			double placeholder = dStack.top();
			dStack.pop();
			
			if (dStack.empty())
			{
				answer = perform(parser, answer, placeholder);
			}
			else
			{
				answer = answer + perform(parser, dStack.top(), placeholder);
				dStack.pop();
			}
		}

	}

	return answer;
}
